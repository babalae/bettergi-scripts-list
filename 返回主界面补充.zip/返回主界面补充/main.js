(async function () {
    setGameMetrics(1920, 1080, 2); // 设置游戏窗口大小和DPI
    await sleep(1000); 
    click(1390, 810); 
    await sleep(1000); 
    click(1390, 810); 
    await sleep(1000); 
    click(1390, 810); 
    log.info("已返回主界面");
})();