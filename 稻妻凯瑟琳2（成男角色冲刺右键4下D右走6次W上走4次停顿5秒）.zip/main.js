(async function () {

    log.info('前往稻妻凯瑟琳');

    async function captureCrystalfly(locationName, x, y, num) {
        log.info('前往 {name}', locationName);
        await genshin.tp(x, y);
        await sleep(5000);
        let filePath = `assets/${locationName}.json`;
        await keyMouseScript.runFile(filePath);
    }

    await captureCrystalfly('稻妻凯瑟琳', -4402.56, -3052.88);
})();